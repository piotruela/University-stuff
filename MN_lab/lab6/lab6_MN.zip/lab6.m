%ZADANIE 2
clear all
load trajektoria1.mat; %wczytanie danych do wektorow x,y,z i n
plot3(x,y,z,'o');
title('\fontsize{16} Wykres polozenia drona dla 1500 probek (blad 5%)')
grid on; 
axis equal;
hold on;
%ZADANIE 4
[wspx, xa] = aproksymacjaWiel(n,x,50);
[wspy, ya] = aproksymacjaWiel(n,y,50);
[wspz, za] = aproksymacjaWiel(n,z,50);
plot3(xa,ya,za,'lineWidth',4);
title('\fontsize{16} Wykres polozenia drona dla 1500 probek wraz z aproksymowana funkcja')
%ZADANIE 5
load trajektoria2.mat;
plot3(x,y,z,'o');
grid on; 
axis equal;
hold on;
[wspx, xa] = aproksymacjaWiel(n,x,50);
[wspy, ya] = aproksymacjaWiel(n,y,50);
[wspz, za] = aproksymacjaWiel(n,z,50);
plot3(xa,ya,za,'lineWidth',4);
title('\fontsize{16} Wykres polozenia drona dla 150 probek (blad 5%)')
%blad jest spowodowany efektem Rungego
clear all;
load trajektoria2.mat
for N = 1:71
  [wspx, xa] = aproksymacjaWiel(n,x,N);
  [wspy, ya] = aproksymacjaWiel(n,y,N);
  [wspz, za] = aproksymacjaWiel(n,z,N);
  temp_sumx = 0;
  temp_sumy = 0;
  temp_sumz = 0;
  for i = 1:length(xa)
    temp_sumx = temp_sumx + (x(i) - xa(i))^2;
    temp_sumy = temp_sumy + (y(i) - ya(i))^2;
    temp_sumz = temp_sumz + (z(i) - za(i))^2;
  end
  temp_sumx = sqrt(temp_sumx)/length(xa);
  temp_sumy = sqrt(temp_sumy)/length(xa);
  temp_sumz = sqrt(temp_sumz)/length(xa);
  err(N) = temp_sumx+temp_sumy+temp_sumz;
end
semilogy(err)
title('\fontsize{16} Wykres bledu od rzedu aproksymacji aprox. wielomianowa')
grid on;
xlabel('Rzad aproksymacji','FontSize',17)
ylabel('Blad','FontSize',17)
%ZADANIE 6
%Sprawdzenie jak dziala aprox_tryg
clear all
load trajektoria2.mat
  [xa] = aprox_tryg(25,n,x);
  [ya] = aprox_tryg(25,n,y);
  [za] = aprox_tryg(25,n,z);
plot3(xa,ya,za,'lineWidth',4);
%aprox_tryg( N, n,x  )
for N = 1:30
  [xa] = aprox_tryg(N,n,x);
  [ya] = aprox_tryg(N,n,y);
  [za] = aprox_tryg(N,n,z);
  temp_sumx = 0;
  temp_sumy = 0;
  temp_sumz = 0;
  for i = 1:length(xa)
    temp_sumx = temp_sumx + (x(i) - xa(i))^2;
    temp_sumy = temp_sumy + (y(i) - ya(i))^2;
    temp_sumz = temp_sumz + (z(i) - za(i))^2;
  end
  temp_sumx = sqrt(temp_sumx)/length(xa);
  temp_sumy = sqrt(temp_sumy)/length(xa);
  temp_sumz = sqrt(temp_sumz)/length(xa);
  err(N) = temp_sumx+temp_sumy+temp_sumz;
end
plot(err)
title('\fontsize{16} Wykres bledu od rzedu aproksymacji aprox. trygonometryczna')
grid on;
xlabel('Rzad aproksymacji','FontSize',17)
ylabel('Blad','FontSize',17)

%WYBIERANIE NAJLEPSZEGO N
minimum = min(err)
best_value = find(err==minimum)
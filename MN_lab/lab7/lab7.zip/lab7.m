clear all

function [ f ] = prawdop(t)
sigma = 3;
mi = 10;
f=(1/(sigma*sqrt(2*pi)))*exp(-(((t-mi)^2)/(2*(sigma^2))));
end

load P_ref.mat;

%metoda prostok�t�w
iter=1;
for N=5:50:1e4
  delta_x = (5-0)/N;
  P=0;
  for i=1:N
    x_i = (i-1)*delta_x;
    x_i_plus_1 = i*delta_x;
    P=P+prawdop((x_i+x_i_plus_1)/2)*delta_x;
  end
  blad_prost(iter)=abs(P-P_ref);
  iter=iter+1;
end

%metoda trapez�w
iter=1;
for N=5:50:1e4
  delta_x = (5-0)/N;
  P=0;
  for i=1:N
    x_i = (i-1)*delta_x;
    x_i_plus_1 = i*delta_x;
    P=P+((prawdop(x_i)+prawdop(x_i_plus_1))/2*delta_x);
  end
  blad_trapez(iter)=abs(P-P_ref);
  iter=iter+1;
end

%metoda Simpsona
iter=1;
for N=5:50:1e4
  delta_x = (5-0)/N;
  P=0;
  for i=1:N
    x_i = (i-1)*delta_x;
    x_i_plus_1 = i*delta_x;
    P=P+((prawdop(x_i)+prawdop(x_i_plus_1)+4*prawdop((x_i_plus_1+x_i)/2)));
  end
  P = P*delta_x/6;
  blad_simpson(iter)=abs(P-P_ref);
  iter=iter+1;
end

%metoda Monte Carlo
min = prawdop(0);
max = prawdop(5);
S = 5*max;
iter=1;
for N=5:50:1e4
  N1=0;
  for i=1:N
    x=rand*5;
    y=rand*max;
    if y<=prawdop(x)
      N1+=1;
    end
  end
  P=N1/N*S;
  blad_monte_carlo(iter)=abs(P_ref-P);
  iter=iter+1;
end
%CZASY
N=1e7;

%metoda prostokatow
delta_x = (5-0)/N;
P=0;
tic;
for i=1:N
  x_i = (i-1)*delta_x;
  x_i_plus_1 = i*delta_x;
  P=P+prawdop((x_i+x_i_plus_1)/2)*delta_x;
end
toc;
czas_prost=toc;

%metoda trapez�w
delta_x = (5-0)/N;
P=0;
tic;
for i=1:N
  x_i = (i-1)*delta_x;
  x_i_plus_1 = i*delta_x;
  P=P+((prawdop(x_i)+prawdop(x_i_plus_1))/2*delta_x);
end
toc;
czas_trapez=toc;

%metoda Simpsona
delta_x = (5-0)/N;
P=0;
tic;
for i=1:N
    x_i = (i-1)*delta_x;
    x_i_plus_1 = i*delta_x;
    P=P+((prawdop(x_i)+prawdop(x_i_plus_1)+4*prawdop((x_i_plus_1+x_i)/2)));
end
P = P*delta_x/6;
toc;
czas_simpson=toc;

%metoda Monte Carlo
min = prawdop(0);
max = prawdop(5);
S = 5*max;
iter=1;
tic;
N1=0;
for i=1:N
  x=rand*5;
  y=rand*max;
  if y<=prawdop(x)
    N1+=1;
  end
end
P=N1/N*S;
toc;
czas_monte_carlo=toc;




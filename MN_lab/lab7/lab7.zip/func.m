function [ f ] = prawdop(t)
sigma = 3;
mi = 10;
a = 1/(sigma*sqrt(2*pi));
b=exp(-(((t-mi)^2)/(2*(sigma^2))));
f=a*b;
end
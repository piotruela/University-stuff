﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml.XPath;

namespace PT_lab3
{
    [XmlType("car")]
    public class Car
    {
        public string model;
        [XmlElement("engine")]
        public Engine motor;
        public int year;

        public Car() { }
        public Car(string model, Engine motor, int year)
        {
            this.model = model;
            this.motor = motor;
            this.year = year;
        }
    }

    public class Engine
    {
        public double displacement;
        public double horsePower;
        [XmlAttribute]
        public string model;

        public Engine() { }
        public Engine(double displacement, double horsePower, string model)
        {
            this.displacement = displacement;
            this.horsePower = horsePower;
            this.model = model;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Car> myCars = new List<Car>() {
                new Car("E250", new Engine(1.8, 204, "CGI"), 2009),
                new Car("E350", new Engine(3.5, 292, "CGI"), 2009),
                new Car("A6", new Engine(2.5, 187, "FSI"), 2012),
                new Car("A6", new Engine(2.8, 220, "FSI"), 2012),
                new Car("A6", new Engine(3.0, 295, "TFSI"), 2012),
                new Car("A6", new Engine(2.0, 175, "TDI"), 2011),
                new Car("A6", new Engine(3.0, 309, "TDI"), 2011),
                new Car("S6", new Engine(4.0, 414, "TFSI"), 2012),
                new Car("S8", new Engine(4.0, 513, "TFSI"), 2012) };
            var LINQ1 = from car in myCars
                        where car.model == "A6"
                        select new
                        {
                            engineType = car.motor.model == "TDI" ? "diesel" : "petrol",
                            hppl = car.motor.horsePower / car.motor.displacement
                        };

            var LINQ2 = from car in LINQ1
                        group car.hppl by car.engineType;

            foreach (var engine in LINQ2)
            {
                Console.WriteLine(engine.Key + ": " + engine.Sum() / engine.Count());
            }

            XmlSerializer serializer = new XmlSerializer(typeof(List<Car>), new XmlRootAttribute("cars"));
            using (var stream = File.OpenWrite("CarsCollection.xml"))
            {
                serializer.Serialize(stream, myCars);
            }

            List<Car> newCars = null;
            XmlSerializer deserializer = new XmlSerializer(typeof(List<Car>), new XmlRootAttribute("cars"));
            using (XmlReader reader = XmlReader.Create("CarsCollection.xml"))
            {
                newCars = (List<Car>)deserializer.Deserialize(reader);
            }

            XElement rootNode = XElement.Load("CarsCollection.xml");
            double avgHP = (double)rootNode.XPathEvaluate("sum(//car/engine[@model!=\"TDI\"]/horsePower) div count(//car/engine[@model!=\"TDI\"]/horsePower)");

            IEnumerable<XElement> models = rootNode.XPathSelectElements("//car/model[not(. = preceding::model)]");

            IEnumerable<XElement> nodes = from car in myCars
                                          select new XElement("car",
                                                      new XElement("model", car.model),
                                                      new XElement("engine",
                                                          new XAttribute("model", car.motor.model),
                                                          new XElement("displacement", car.motor.displacement),
                                                          new XElement("horsePower", car.motor.horsePower)
                                                      ),
                                                      new XElement("year", car.year)
                                                 );
            XElement rootNode1 = new XElement("cars", nodes); //create a root node to contain the query results
            rootNode1.Save("CarsFromLinq.xml");

            XElement xhtml = XElement.Load("template.html");
            XElement body = xhtml.Element("{http://www.w3.org/1999/xhtml}body");
            IEnumerable<XElement> rows = from car in myCars
                                         select new XElement("tr",
                                                     new XElement("td", car.model),
                                                     new XElement("td", car.motor.model),
                                                     new XElement("td", car.motor.displacement),
                                                     new XElement("td", car.motor.horsePower),
                                                     new XElement("td", car.year)
                                                );
            body.Add(new XElement("table", rows));
            xhtml.Save("table.html");

            XElement root = XElement.Load("CarsCollection.xml");
            foreach (XElement e in root.Elements())
            {
                foreach (XElement e2 in e.Elements())
                {
                    if (e2.Name == "model")
                        e2.SetAttributeValue("year", e.Element("year").Value);
                    foreach (XElement e3 in e2.Elements())
                    {
                        if (e3.Name == "horsePower")
                            e3.Name = "hp";
                    }
                }
                e.SetElementValue("year", null);
            }
            root.Save("CarsCollection_modified.xml");
            Console.Read();
        }

    }
}
